<?php

return
[
    'v_bookings' => 'Reservering voertuigen',
    'p_bookings' => 'Reservering personen',
    't_bookings' => ' ',
    'user_name' => 'Gebruikersnaam',
    'user_email' => 'Gebruikers e-mail',
    'check_in' => 'Aankomst',
    'check_in_capture' => 'Aankomst Capture',
    'check_out' => 'Vertrek',
    'check_out_capture' => 'Vertrek Capture',
    'transaction_imgs' => 'Transactie afbeeldingen',
    'transactions' => 'transacties',
    'vehicle_transactions' => 'Voertuigtransacties',
    'attendant_name' => 'Naam bezoeker',
    'v_number' => 'Kenteken',
    'contact_details' => 'Contactdetails'
];

