<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
    [
        'regression' => 'Regressie testen',
        'choose_setting' => 'Kies locatie',
        'current_location' => 'Huidige locatie',
        'other_location' => 'Andere locatie',
        'choose_devices' => 'Kies Apparaat',
        'identifier' => 'Barcode / Plate Number',
        'submit' => 'Test uitvoeren',
        'ticket_reader' => 'Ticketlezer',
        'ticket_reader_person' => 'Ticketlezer persoon',
        'plate_reader' => 'Plaatlezer',
        'key' => 'Sleutel',
        'choose_lang' => 'Kies Talen',
        'vehicle_number' => 'Voertuignummer',
        'confidence' => 'Vertrouwen',
        'sign_in' => 'Sign In',
        'session_id' => 'Sessie-ID testen',
        'date' => 'Datum Tijd',
        'choose_case' => 'Gerelateerde ticketlezer/plaatlezer',
        'related_ticket_reader' => 'Gerelateerde ticketlezer',
        'image_type' => 'Beeldtype',
        'file' => 'Bestand',
        'base_64' => 'Basisgecodeerd 64',
        'already_account' => 'Already have an account?',
    'import-json-data' => 'Importeer Json',
    'really' => 'Omdat ik deze regel echt wil inschakelen. Als dit het geval is, wordt de crossponding-regel uitgeschakeld'
    ];
