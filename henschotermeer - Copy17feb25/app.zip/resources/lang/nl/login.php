<?php

return
        [
            'sign_in' => 'Aanmelden',
            'email' => 'E-mail',
            'pass' => 'Wachtwoord',
            'remember-me' => 'Onthoud mij',
            'forgot-pwd' => 'Wachtwoord vergeten?',
            'log-in' => 'Log In',
];
