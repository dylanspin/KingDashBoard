<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
        [
            'edit_customer' => 'Reservering bewerken',
            'person_info' => 'Persoonsinfo',
            'name' => 'Naam',
            'enter_name' => 'Voer naam in',
            'email' => 'E-mail',
            'enter_email' => 'Voer email in',
            'max_cars' => "Maximum aantal auto's",
            'enter_max_cars' => "Voer maximaal aantal auto's in",
            'address' => 'Adres',
            'street' => 'Straat',
            'city' => 'Plaats',
            'country' => 'land',
            'post_code' => 'Postcode',
            'phone' => 'Telefoonnummer',
            'vehicles' => 'voertuigen',
            'vehicle' => 'Voertuig',
            'plate_number' => 'Kenteken nummer',
            'add_more' => 'Voeg meer kentekens toe',
            'new_plate' => 'Voer hier een nieuw kenteken in',
            'save' => 'Opslaan',
            'cancel' => 'Annuleren',
            //Messages
            'customer_notfound' => 'Reservering niet gevonden',
            'customer_delete' => 'Reservering is verwijderd',
            'confirmation' => 'Bevestigen',
            'user_arrival_notification' => 'E-mail melding ontvangen wanneer deze reservering is ingereden?',
            'notify_email' => 'E-mailadres voor het ontvangen van meldingen',
            'notify_email_note' => 'Voer meer dan 1 e-mails in met komma (,) gescheiden.',
];

