<?php

return
        [
            'sign_up' => 'Inschrijven',
            'name' => 'Naam',
            'email' => 'E-mail',
            'pass' => 'Wachtwoord',
            'confirm_pass' => 'Bevestig wachtwoord',
            'term&conditions' => 'Ik ga akkoord met de voorwaarden',
            'terms' => 'Voorwaarden',
            'sign_in' => 'Aanmelden',
            'already_account' => 'Heb je al een account?'
];
