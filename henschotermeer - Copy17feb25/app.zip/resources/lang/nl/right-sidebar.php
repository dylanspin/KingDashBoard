<?php

return
[
    'account_settings' => 'Account instellingen',
    'logout' => 'Uitloggen',
    'login' => 'Login',
    'register' => 'Registreren',
    'actions' => 'acties',
    'checkout_person' => 'Aanwezigheidslijst personen opschonen',
    'checkout_vehicle' => 'Aanwezigheidslijst voertuigen opschonen'
];
