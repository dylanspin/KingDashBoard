<?php

return[
    'history' => 'History',
    'no' => 'NO',
    'booking_id' => 'Booking ID',
    'vehicle_num' => 'Vehicle Number',
    'tommy_parent' => 'Tommy Parent',
    'name' => 'Name',
	'bookings'=>'Tommy Geschiedenis Boekingen'

    
];