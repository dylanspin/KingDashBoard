<?php

return
        [
            'loc_ratings' => 'Beoordelingen',
            'title' => 'Titel',
            'address' => 'Adres',
            'rating' => 'Beoordeling'
];
