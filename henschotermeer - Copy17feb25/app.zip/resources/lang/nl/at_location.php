<?php

return
[
    'curr_location' => 'Aanwezigheidslijst',
    'name' => 'Naam',
    'email' => 'E-mail',
    'phone' => 'Telefoon',
    'vehicle' => 'Voertuig',
    'amount' => 'Bedrag',
    'checkin' => 'Aankomst',
    'checkout' => 'Vertrek',
    'transactions' => 'Transacties',
    'img' => 'Afbeelding',
    'check_in' => 'Aankomst',
    'check_out' => 'Vertrek',
    'contact_details' => 'Contact details',
    'type' => 'Type',
    'entry' => 'Ingereden',
    'exit' => 'Uitgereden',
    'device' => 'Apparaat',
    'status' => 'Status',
	'transaction_details' => 'Transactie details'
];

