<?php

return[

	
'add_reservation' => 'Handmatige reserveringen',
'add_reservation_button' => '+ Reserveringen toevoegen',
'add_person_reservation' => 'Persona Reservering',
'edit'=>'Bewerk',
'delete'=>'Verwijderen',
'name'=>'Naam',
'plate'=>'Nummerplaat',
'check_in'=>'inchecken',
'check_out'=>'uitchecken',
'action'=>'Actie',
'sure'=>'Weet je zeker dat?',
'really'=>'Wilt u deze record echt verwijderen?',
'cancel'=>'Annuleren',
'close'=>'Dichtbij',
'save'=>'Sparen',
'add'=>'Reserveringen toevoegen',
'individual'=> 'Naam is vereist',
'license'=> 'Kentekennummer is vereist',
'sucess'=>'Met succes verwijderd',
'sucessfull'=>'Succes',
'win'=>'Gegevens zijn succesvol ingevoerd',
'update'=>'gegevens zijn succesvol bijgewerkt'

];


?>