<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'account_settings' => 'Account Settings',
    'user_profile' => 'User Profile',
    'bio' => 'Description',
    'address' => 'Address', 
    'name' => 'Name',
    'email' => 'Email',
    'password_msg' => 'If you dont want to change password... please leave them empty',
    'pass' => 'Password',
    'confirm_pass' => 'Confirm Password',
    'dob' => 'Date Of Birth',
    'profile_pic' => 'Profile Picture',
    'select_img' => 'Select Image',
    'change' => 'Change',
    'remove' => 'Remove',
    'brief_intro' => 'Brief Intro',
    'gender' => 'Gender',
    'select' => 'Select',
    'select_gender' => 'Select Gender...',
    'male' => 'Male',
    'female' => 'Female',
    'other' => 'Other',
    'country' => 'Country',
    'state' => 'State',
    'city' => 'City',
    'postal' => 'Postal/zip',
    'prev' => 'Previous',
    'nxt' => 'Next',
    'finish' => 'Finish',
    'error_msg' => 'Errors! Please fill form with proper details'
    
];
