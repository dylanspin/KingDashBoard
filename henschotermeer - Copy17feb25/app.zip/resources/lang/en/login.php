<?php

return [
    'sign_in' => 'Sign In',
    'email' => 'Email',
    'pass' => 'Password',
    'remember-me' => 'Remember me',
    'forgot-pwd' => 'Forgot password?',
    'log-in' => 'Log In',
];
