<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
    [
        'regression' => 'Regression Testing',
        'choose_setting' => 'Choose Location',
        'current_location' => 'Current Location',
        'other_location' => 'Other Location',
        'choose_devices' => 'Choose Device',
        'identifier' => 'Barcode / Plate Number',
        'submit' => 'Run Test',
        'sign_in' => 'Sign In',
        'ticket_reader'=>'Ticket Reader',
        'ticket_reader_person'=>'Ticket Reader Person',
        'plate_reader'=>'Plate Reader',
        'key'=>'Key',
        'choose_lang'=>'Choose Languages',
        'vehicle_number'=> 'Vehicle Number',
        'confidence'=>'Confidence',
        'type'=>'Type',
        'message'=>'Message',
        'session_id'=>'Testing Session Id',
        'date'=>'Date/Time',
        'choose_case'=>'Choose Case',
        'related_ticket_reader'=>'Related Ticket Reader / Plate Reader',
        'image_type'=>'Image Type',
        'file'=>'File',
        'base_64'=>'Base Encoded 64',
        'already_account' => 'Already have an account?',
        'import-json-data'=> 'Import Json',
        'ok'=>'Yes',
        'cancel'=>'Cancel'
    ];
