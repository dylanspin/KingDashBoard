<?php

return[

	
'add_reservation' => 'Manual Reservations',
'add_reservation_button'=>'+ Add Reservations',
'add_person_reservation' => 'Person Reservation',
'edit'=>'Edit',
'delete'=>'Delete',
'name'=>'Name',
'plate'=>'License Plate',
'check_in'=>'Check-in Time ',
'check_out'=>'Check-out Time ',
'action'=>'Action',
'sure'=>'Are You Sure?',
'really'=>'Do you really want to delete this record?',
'cancel'=>'Cancel',
'close'=>'Close',
'save'=>'Save',
'add'=>'Add Reservations',
'individual'=> 'Name is required',
'license'=> 'License Plate number is required',
'sucess'=>'Deleted Successfully',
'sucessfull'=>'Sucess',
'win'=>'Data is inserted successfully',
'update'=>'Data is Updated Successfully'
];


?>