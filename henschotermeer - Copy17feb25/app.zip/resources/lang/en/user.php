<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return [
    //Messages
    'user_name_required' => 'The name is required',
    'user_confirm_password_not_match' => 'Confirm Password should match with password',
    'user_email_required' => 'The email address is required',
    'user_email_not_valid' => 'The input is not a valid email address',
    'user_gender_required' => 'You must select a gender',
    'account_update' => 'Account has been updated',
    'name' => 'Name',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',
    'add' => 'Add',
    'select' => 'Select',
    'no' => 'No',
    'email' => 'Email',
    'role' => 'Role',
    'actions' => 'Actions'
];
