<?php

return[
    'history' => 'Geschiedenis',
    'no' => 'No',
    'booking_id' => 'Boekings-ID',
    'vehicle_num' => 'Voertuignummer',
    'tommy_parent' => 'Tommy Parent',
    'name' => 'Naam',
	'bookings'=>'Tommy History Bookings'
    
];