<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return 
[
    'account_settings' => 'Account Settings',
    'logout' => 'Logout',
    'login' => 'Login',
    'register' => 'Register',
    'actions' => 'Actions',
    'checkout_person' => 'CheckOut Person',
    'checkout_vehicle' => 'CheckOut Vehicle'
];
