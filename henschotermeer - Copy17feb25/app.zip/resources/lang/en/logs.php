<?php

return [
    //Index
    'logs' => 'Error Logs',
    'message' => 'Error Message',
    'type' => 'Error Type',
    'line' => 'Error Line#',
    'added_at' => 'Added At',
    'actions' => 'Actions',
    'resolved' => 'Resolved',
    //Message
    'message_update' => 'Log has been updated.',
];
