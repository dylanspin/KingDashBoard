<?php
return [
    'bounces_email' => 'Bounced Emails',
    'no' => 'No',
    'email' => 'Email',
	'name' => 'Name',
    'reason' => 'Reason',
	'booking_ref' => 'Booking Id',
    'bounce_date'  => 'Bounce Date',
    'search'  => 'Search',
    'search_in'  => 'Search In',
    'reset'  => 'Reset filter',
    'export_to_excel'  => 'Export to Excel',
];