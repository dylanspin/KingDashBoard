<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LatestVehicleTransactions extends Model {

    protected $table = 'LatestVehicleTransactions';

}
