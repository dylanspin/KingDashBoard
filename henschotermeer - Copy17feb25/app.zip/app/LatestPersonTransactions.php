<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LatestPersonTransactions extends Model {

    protected $table = 'LatestPersonTransactions';

}
