<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpIdealSourceDetails extends Model {
    
}
