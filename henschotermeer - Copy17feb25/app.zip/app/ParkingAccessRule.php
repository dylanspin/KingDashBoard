<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParkingAccessRule extends Model
{
    //
    
}
