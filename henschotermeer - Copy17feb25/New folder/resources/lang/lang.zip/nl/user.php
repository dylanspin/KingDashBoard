<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return [
    //Messages
    'user_name_required' => 'De naam is verplicht',
    'user_confirm_password_not_match' => 'Bevestig wachtwoord moet overeenkomen met wachtwoord',
    'user_email_required' => 'Het e-mailadres is verplicht',
    'user_email_not_valid' => 'De invoer is geen geldig e-mailadres',
    'user_gender_required' => 'U moet een geslacht selecteren',
    'account_update' => 'Account is bijgewerkt'
];
