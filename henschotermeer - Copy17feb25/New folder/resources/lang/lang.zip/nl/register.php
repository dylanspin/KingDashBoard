<?php

return
        [
            'sign_up' => 'Inschrijven',
            'name' => 'Naam',
            'email' => 'E-mail',
            'pass' => 'Wachtwoord',
            'confirm_pass' => 'bevestig wachtwoord',
            'term&conditions' => 'Ik ben het met iedereen eens',
            'terms' => 'Voorwaarden',
            'sign_in' => 'Aanmelden',
            'already_account' => 'Heb je al een account?'
];
