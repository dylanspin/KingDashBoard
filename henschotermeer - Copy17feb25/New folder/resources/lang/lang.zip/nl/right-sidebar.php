<?php

return
        [
            'account_settings' => 'Account instellingen',
            'logout' => 'Uitloggen',
            'login' => 'Login',
            'register' => 'Registreren',
            'actions' => 'acties'
];
