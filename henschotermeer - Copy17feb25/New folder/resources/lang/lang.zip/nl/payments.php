<?php

return
        [
            'payments' => 'betalingen',
            't_amount' => 'Totale hoeveelheid :',
            't_bookings' => 'Totale boekingen :',
            'name' => 'Naam',
            'type' => 'Type',
            'no' => 'No',
            'date' => 'Datum',
            'vehicle' => 'Voertuig',
            'amount' => 'Bedrag',
            'arrival' => 'Aankomst',
            'departure' => 'Vertrek'
];
