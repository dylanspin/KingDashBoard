<?php

return [
    //Index
    'messages' => 'berichten',
    'add_message' => 'Bericht toevoegen',
    'message_en_uk' => 'Bericht Engels (VK)',
    'message_dutch_nl' => 'Bericht Nederlands (Nederland)',
    'delete' => 'Verwijder',
    'key' => 'Sleutel',
    'actions' => 'acties',
    'edit' => 'Bewerk',
    'view' => 'Uitzicht',
    //Edit,Create
    'message' => 'Bericht',
    'details' => 'Details',
    'message_in' => 'Bericht in',
    'finish' => 'Af hebben',
    //Message
    'message_key_required' => 'Berichtsleutel is vereist',
    'message_lang_en_required' => 'Bericht in het Engels is verplicht',
    'message_add' => 'Bericht is toegevoegd.',
    'message_update' => 'Bericht is bijgewerkt.',
    'message_delete' => 'Bericht is verwijderd',
    'message_not_found' => 'Bericht niet gevonden'
];
