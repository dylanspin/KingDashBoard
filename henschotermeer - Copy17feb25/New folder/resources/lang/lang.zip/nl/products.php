<?php

return [
    'person_ticket_added' => 'Persoonskaart is succesvol toegevoegd',
    'person_ticket_updated' => 'Persoonsbewijs succesvol geüpdatet',
    'day_ticket_added' => 'Dagkaart succesvol toegevoegd',
    'day_ticket_updated' => 'Dagkaart succesvol bijgewerkt',
    'day_ticket' => 'Dagkaart',
    'person_ticket' => 'Persoon Ticket',
    'title' => 'Titel',
    'title_nl' => 'Titel NL',
    'price' => 'Prijs',
    'submit' => 'voorleggen'
];
