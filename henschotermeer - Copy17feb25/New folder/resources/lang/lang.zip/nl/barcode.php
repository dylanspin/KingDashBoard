<?php

return [
    //Index
    'barcodes' => 'Barcodes',
    'add_barcode' => 'Voeg streepjescode toe',
    'delete' => 'Verwijder',
    'key' => 'Sleutel',
    'name' => 'Naam',
    'vehicle_no' => 'Voertuignummer',
    'actions' => 'acties',
    'edit' => 'Bewerk',
    'view' => 'Uitzicht',
    //Edit,Create
    'view_barcodes' => 'Bekijk streepjescodes',
    'barcode' => 'Barcode',
    'details' => 'Details',
    'message' => 'Bericht',
    'finish' => 'Af hebben',
    'submit' => 'voorleggen',
    //Message
    'barcode_required' => 'Barcode is verplicht',
    'barcode_name_required' => 'Naam is vereist',
    'barcode_vehicle_no_required' => 'Voertuignummer is verplicht',
    'barcode_add' => 'Barcode is toegevoegd',
    'barcode_update' => 'Barcode is bijgewerkt',
    'barcode_delete' => 'Barcode is verwijderd',
    'barcode_not_found' => 'Barcode niet gevonden'
];
