<?php


return
        [
            //Step-0
            'conn_details' => 'Voer databaseverbindingsdetails in',
            'user' => 'Gebruiker',
            'port' => 'Port',
            'pass' => 'Wachtwoord',
            'db_name' => 'Db Naam',
            'nxt' => 'volgende',
            //step-1
            'activation_key' => 'Voer de activeringscode in die wordt geleverd door Parkingshop',
            'active_key' => 'Activatie sleutel',
            //step-2
            'add_device_info' => 'Wilt u Devices Information invoeren? U kunt dit later toevoegen.',
            'yes' => 'ja',
            'no' => 'Nee',
            //Step-3
            'ticket_reader_no' => 'Hoeveel kaartlezer die u op deze locatie wilt configureren?',
            'ticket_readers' => 'Ticketlezers',
            'person_ticket_readers' => 'Kaartlezers voor personen',
            'plate_readers' => 'Plate Readers',
            'outdoor_display' => 'Buitendisplay',
            //Step4
            'conf_ticket_reader' => 'Configuratie van kaartlezers',
            'name_ticket_reader' => 'Naam voor kaartlezer',
            'device_direction' => 'Apparaatrichting',
            'bi_directional' => 'Bi-Directional',
            'in' => 'In',
            'out' => 'uit',
            'port_treader' => 'Poort voor kaartlezer',
            'ip_treader' => 'Ip voor kaartlezer',
            'skip' => 'Overspringen',
            'import' => 'Instellingen importeren naar apparaat?',
            //Step-5
            'config_person_TReader' => 'Configuratie van kaartlezers voor personen',
            'name_person_TReader' => 'Naam voor persoonskaartlezer',
            'ip_preader' => 'Ip voor Person Ticket Reader',
            'port_preader' => 'Port voor Person Ticket Reader',
            //Step-6
            'config_plate_reader' => 'Configuratie van plaatlezers',
            'name_plate_reader' => 'Naam voor plaatlezer',
            'port_plate_reader' => 'Poort voor plaatlezer',
            'ip_plate_reader' => 'Ip voor Plate Reader',
            //Step7
            'config_outdoor_display' => 'Configuratie van buitendisplay',
            'name_outdoor_display' => 'Naam voor buitendisplay',
            'port_outdoor_display' => 'Poort voor buitendisplay',
            'ip_outdoor_display' => 'IP voor buitendisplay',
            //Step-8
            'thanks' => 'Bedankt voor de Compleeting-wizard.',
            'finish' => 'Af hebben'
];
