<?php

return
        [
            'curr_location' => 'Momenteel op Locatie',
            'name' => 'Naam',
            'email' => 'E-mail',
            'phone' => 'Phone',
            'vehicle' => 'Voertuig',
            'amount' => 'Bedrag',
            'checkin' => 'Check in',
            'transactions' => 'transacties',
            'img' => 'Beeld',
            'check_in' => 'Check in',
            'check_out' => 'Check out'
];

