<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
        [
            'title' => 'Tommy Reserveringen',
            'import_data' => 'Data importeren',
            'no' => 'No',
            'email' => 'E-mail',
            't_members' => 'leden',
            'arrival_date' => 'Aankomstdatum',
            'departure_date' => 'Vertrekdatum',
            'license_plate' => 'Nummerplaat',
            'actions' => 'acties',
            'send_ticket' => 'Verzend ticket',
            'delete' => 'Verwijder',
            'name' => 'Naam',
            'family_status' => 'Familie status',
            'dob' => 'Geboortedatum',
            'mem_of' => 'Lid van',
            
            //Import
            'import_reservation' => 'Reservering importeren',
            'view_reservations' => 'Bekijk reserveringen',
            'file_chooser' => 'Kies uw xls / csv-bestand:',
            'import' => 'Importeren',
            'print' => 'Ticket afdrukken',
            'family_name' => 'Achternaam'
];
