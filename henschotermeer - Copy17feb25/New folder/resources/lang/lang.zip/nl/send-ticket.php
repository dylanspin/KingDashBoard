<?php

return [
    //Index
    'send_ticket' => 'Verzend ticket',
    'details' => 'Details',
    'first_name' => 'Voornaam',
    'last_name' => 'Achternaam',
    'email' => 'E-mail',
    'phone_num' => 'Telefoonnummer',
    'checkin_date' => 'Check-in datum',
    'checkin_time' => 'CheckIn Time',
    'checkout_date' => 'Vertrek datum',
    'checkout_time' => 'Check-uit tijd',
    'vehicle_num' => 'Voertuignummer',
    'sender_name' => 'Naam afzender',
    'message' => 'Bericht',
    'finish' => 'Af hebben',
    'submit' => 'voorleggen',
    //Message
    'first_name_required' => 'Voornaam is verplicht',
    'last_name_required' => 'Achternaam is verplicht',
    'email_required' => 'E-mail is verplicht',
    'email_valid' => 'Vul een geldig emailadres in',
    'phone_num_required' => 'Telefoon is verplicht',
    'checkin_date_required' => 'CheckIn Date is verplicht',
    'checkin_time_required' => 'CheckIn Time is verplicht',
    'checkout_date_required' => 'CheckOut Date is verplicht',
    'checkout_time_required' => 'Checkout Time is vereist',
    'vehicle_num_required' => 'Voertuignummer is verplicht',
    'ticket_send' => 'Ticket verzonden met succes'
];
