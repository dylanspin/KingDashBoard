<?php

return [
    'groups' => 'groepen',
    'add_group' => 'Groep toevoegen',
    'no' => 'Nee',
    'group_name' => 'Groepsnaam',
    'no_of_devices' => 'apparaten',
    'actions' => 'acties',
    'edit' => 'Bewerk',
    'delete' => 'Verwijder',
    'edit_group' => 'Groep bewerken',
    'view_groups' => 'Bekijk Groepen',
    'name' => 'Naam',
    'devices' => 'apparaten',
    'submit' => 'voorleggen',
    'device_title' => 'Selecteer apparaten ...',
    'create_group' => 'Maak een groep',
    //Messages
    'group_name_required' => 'De naam is verplicht',
    'group_device_required' => 'Selecteer een apparaat',
    'group_added' => 'Groep is toegevoegd.',
    'group_already_added' => 'Groep al toegevoegd.',
    'group_updated' => 'Groep is bijgewerkt.',
    'group_not_found' => 'Groep niet gevonden.',
    'group_deleted' => 'Groep is verwijderd.',
];

