<?php

return
        [
            'v_bookings' => 'Voertuigboekingen',
            't_bookings' => 'Totale boekingen',
            'user_name' => 'Gebruikersnaam',
            'user_email' => 'Gebruikers e-mail',
            'check_in' => 'Check In',
            'check_out' => 'check Out',
            'transaction_imgs' => 'Transactie afbeeldingen',
            'vehicle_transactions' => 'Voertuigtransacties',
            'attendant_name' => 'Attendant naam',
            'v_number' => 'Voertuignummer'
];

