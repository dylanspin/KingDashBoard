<?php

return
        [
            't_bookings' => 'Totale boekingen',
            't_payments' => 'Total Payments',
            'booking_details' => 'Boekingsdetails',
            'booking_transactions' => 'Boekingstransacties',
            'check_in' => 'Check In',
            'check_out' => 'Check Out',
            'vehicle_no' => 'Voertuignummer',
            'attendant_name' => 'Attendant naam',
            'trans_img' => 'Transactie afbeelding',
            'user_name' => 'Gebruikersnaam',
            'email' => 'E-mail',
            'booking_payment' => 'Reserveringsbetaling'
];

