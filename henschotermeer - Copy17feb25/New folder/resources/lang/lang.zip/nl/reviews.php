<?php

return
        [
            'loc_ratings' => 'Locatiegegevens',
            'title' => 'Titel',
            'address' => 'Adres',
            'rating' => 'Beoordeling'
];
