<?php

return [
    'person_ticket_added' => 'Person ticket added successfully',
    'person_ticket_updated' => 'Person ticket updated successfully',
    'day_ticket_added' => 'Day ticket added successfully',
    'day_ticket_updated' => 'Day ticket updated successfully',
    'day_ticket' => 'Day Ticket',
    'person_ticket' => 'Person Ticket',
    'title' => 'Title',
    'title_nl' => 'Title NL',
    'price' => 'Price',
    'submit' => 'Submit'
];
