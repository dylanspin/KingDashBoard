<?php

return
        [
            'curr_location' => 'Currently at Location',
            'name' => 'Name',
            'email' => 'Email',
            'phone' => 'Phone',
            'vehicle' => 'Vehicle',
            'amount' => 'Amount',
            'checkin' => 'Check_in',
            'transactions' => 'Transactions',
            'img' => 'Image',
            'check_in' => 'Check-in',
            'check_out' => 'Check-out'
            
];

