<?php

return
        [
            't_bookings' => 'Total Bookings',
            't_payments' => 'Total Payments',
            'booking_details' => 'Booking Details',
            'booking_transactions' => 'Booking Transactions',
            'check_in' => 'Check In',
            'check_out' => 'Check Out',
            'vehicle_no' => 'Vehicle Number',
            'attendant_name' => 'Attendant Name',
            'trans_img' => 'Transaction Image',
            'user_name' => 'User Name',
            'email' => 'Email',
            'booking_payment' => 'Booking Payment'
];

