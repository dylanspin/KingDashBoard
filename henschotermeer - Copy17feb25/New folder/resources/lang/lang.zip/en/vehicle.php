<?php

return
        [
            'v_bookings' => 'Vehicle Bookings',
            't_bookings' => 'Total Bookings',
            'user_name' => 'User Name',
            'user_email' => 'User Email',
            'check_in' => 'Check In',
            'check_out' => 'check Out',
            'transaction_imgs' => 'Transaction Images',
            'vehicle_transactions' => 'Vehicle Transactions',
            'table_text' => 'Create responsive tables by wrapping any',
            'attendant_name' => 'Attendant Name',
            'v_number' => 'Vehicle Number'
];

