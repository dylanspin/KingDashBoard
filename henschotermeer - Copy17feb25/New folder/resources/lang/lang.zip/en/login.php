<?php

return [
    'sign_in' => 'Sign In',
    'email' => 'Email',
    'pass' => 'Password',
    'remember-me' => 'Rememebr me',
    'forgot-pwd' => 'Forgot pwd?',
    'log-in' => 'Log In',
];
