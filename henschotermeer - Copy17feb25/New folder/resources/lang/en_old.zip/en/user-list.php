<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'create_userlist' => 'Create Userlist User',
    'view_users' => 'View Users',
    'personal' => 'Personal',
    'vehicle' => 'Vehicle',
    'loc' => 'Location',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'select_group' => 'Select Group',
    'group_title' => 'Group Title',
    'note' => 'Note',
    'brief_intro' => 'Brief Intro',
    'max_length' => 'Max line length of 100 characters.',
    'vehicle_name' => 'Vehicle Name',
    'vehicle_no' => 'Vehicle Number',
    'doors_range' => 'Doors Range',
    'bikes_range' => 'Bikes range',
    'ev_charger_range' => 'EV Charger Range',
    'energy_limit' => 'Energy Limit',
    'lang' => 'Language',
    'select_title' => 'Select Language...',
    'select' => 'Select',
    'prev' => 'Previous',
    'nxt' => 'Next',
    'finish' => 'Finish',
    'userslist' => 'Users List',
    'group' => 'Group',
    'add_user' => 'Add User',
    'no' => 'No',
    'user_name' => 'User Name',
    'added_at' => 'Added At',
    'actions' => 'Actions',
    'send_instructions' => 'Send Instructions',
    'block' => 'Block',
    'send' => 'Send',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'deleted_userslist' => 'Deleted Users List',
    'role' => 'Role',
    'permissions' => 'Permissions',
    'restore' => 'Restore',
    'edit_userlist' => 'Edit Userlist User',
    
];
