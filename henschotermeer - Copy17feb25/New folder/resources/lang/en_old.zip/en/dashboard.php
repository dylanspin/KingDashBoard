<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'week_revenue' => 'Week Revenue',
    'current_week' => 'CURRENT WEEK VISIT',
    'last_week' => 'LAST WEEK',
    'booked_spots' => 'BOOKED SPOTS WEEK',
    'new_sales' => 'New Sales',
    'live' => 'Live',
    'visited' => 'Visited',
    'expecting' => 'Expecting',
    'currently_loc' => 'Currently At Location',
    'select_transaction' => 'Select Transaction',
    'select' => 'Select',
    'vehicles_on_loc' => 'Vehicles On Location',
    'select' => 'Select',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'vehicle' => 'Vehicle',
    'amount' => 'Amount',
    'check_in' => 'Check-in',
    

];
