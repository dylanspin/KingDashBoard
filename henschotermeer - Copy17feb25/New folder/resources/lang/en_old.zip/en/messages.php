<?php

return
        [
            //Index
            'messages' => 'Messages',
            'add_message' => 'Add Message',
            'message_en_uk' => 'Message English (UK)',
            'message_dutch_nl' => 'Message Dutch (Netherland)',
            'delete' => 'Delete',
            'key' => 'Key',
            'actions' => 'Actions',
            'edit' => 'Edit',
            'view' => 'View',
            
            //Edit,Create
            
            'message' => 'Message',
            'details' => 'Details',
            'message_in' => 'Message in',
            'finish' => 'Finish'
];
