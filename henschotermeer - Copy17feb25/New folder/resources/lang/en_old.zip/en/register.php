<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'sign_up' => 'Sign Up',
    'name' => 'Name',
    'email' => 'Email',
    'pass' => 'Password',
    'confirm_pass' => 'Confirm Password',
    'term&conditions' => 'I agree to all',
    'terms' => 'Terms',
    'sign_in' => 'Sign In',
    'already_account' => 'Already have an account?'
];
