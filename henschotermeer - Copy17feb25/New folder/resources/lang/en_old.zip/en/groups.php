<?php

return
        [
            'groups' => 'Groups',
            'add_group' => 'Add Group',
            'no' => 'No',
            'group_name' => 'Group Name',
            'no_of_devices' => 'No. Of Devices',
            'actions' => 'Actions',
            'edit' => 'Edit',
            'delete' => 'Delete',
            'edit_group' => 'Edit Group',
            'view_groups' => 'View Groups',
            'name' => 'Name',
            'devices' => 'Devices',
            'submit' => 'Submit',
            'device_title' => 'Select Devices...',
            'create_group' => 'Create Group'
];

