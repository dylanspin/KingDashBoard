<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
        [
            //Manage WhiteList
            'white_list' => 'White List',
            'add_user' => 'Add User',
            'no' => 'No',
            'user_name' => 'User Name',
            'email' => 'Email',
            'ticket_status' => 'Ticket Status',
            'added_at' => 'Added At',
            'send_ins' => 'Send Instructions',
            'send' => 'Send',
            'delete' => 'Delete',
            'actions' => 'Actions',
            'group' => 'Group',
            
            
            //Create WhiteList
            'create_white_list' => 'Create Whitelist User',
            'view_users' => 'View Users',
            'select_group' => 'Select Group',
            'select_group_title' => 'Select Group...',
            'submit' => 'Submit',
            
            //Delete WhiteList
            'deleted_user' => 'Deleted User List',
            'name' => 'Name',
            'role' => 'Role',
            'permissions' => 'Permissions',
            'restore' => 'Restore',
            
            //Edit WhiteList
            'edit_whitelist' => 'Edit Whitelist User',
            'personal' => 'Personal',
            'vehicle' => 'Vehicle',
            'loc' => 'Location',
            'phone' => 'Phone',
            'note' => 'Note',
            'brief_intro' => 'Brief Intro',
            'max_length' => 'Max line length of 100 characters.',
            'vehicle_name' => 'Vehicle Name',
            'vehicle_no' => 'Vehicle Number',
            'doors_range' => 'Doors Range',
            'bikes_range' => 'Bikes Range',
            'ev_charger_range' => 'EV Charger Range',
            'energy_limit' => 'Energy Limit',
            'lang' => 'Language',
            'select_title' => 'Select Language...',
            'select' => 'Select',
            'prev' => 'Previous',
            'nxt' => 'Next',
            'finish' => 'Finish',
];
