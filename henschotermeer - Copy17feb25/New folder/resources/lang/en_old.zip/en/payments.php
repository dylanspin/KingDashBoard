<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'payments' => 'Payments',
    't_amount' => 'Total Amount :',
    't_bookings' => 'Total Bookings :',
    'name' => 'Name',
    'type' => 'Type',
    'no' => 'No',
    'date' => 'Date',
    'vehicle' => 'Vehicle',
    'amount' => 'Amount',
    'arrival' => 'Arrival',
    'departure' => 'Departure'
];
