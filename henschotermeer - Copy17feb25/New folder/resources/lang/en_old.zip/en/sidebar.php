<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return [
 
    'account_setting' => 'Account Setting',
    'logout' => 'Logout',
    'user_list' => 'User List',
    'manage_user' => 'Manage Users',
    'add_new_user' => 'Add New User',
    'white_list' => 'White List',
    'tommy_reservation' => 'Tommy Reservations',
    'manage_reservations' => 'Manage Reservations',
    'devices' => 'Devices',
    'import_reservation' => 'Import Reservation',
    'manage_devices' => 'Manage Devices',
    'add_new_device' => 'Add New Device',
    'reviews' => 'Reviews',
    'group' => 'Group',
    'manage_group' => 'Mange Groups',
    'add_new_group' => 'Add New Group',
    'messages' => 'Messages',
    'manage_messages' => 'Manage Messages',
    'add_new_message' => 'Add New Message',
    'payments' => 'Payments',
    'attendants' => 'Attendants',
    'loc_setting' => 'Location Settings',
    'account_settings' => 'Account Settings',
    
];
?>

