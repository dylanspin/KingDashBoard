<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
        [
            'edit_customer' => 'Edit Customer',
            'person_info' => 'Person Info',
            'name' => 'Name',
            'enter_name' => 'Enter Name',
            'email' => 'Email',
            'enter_email' => 'Enter Email',
            'max_cars' => 'Maximum Cars',
            'enter_max_cars' => 'Enter Maximum Cars',
            'address' => 'Address',
            'street' => 'Street',
            'city' => 'City',
            'country' => 'Country',
            'post_code' => 'Post Code',
            'phone' => 'Phone Number',
            'vehicles' => 'Vehicles',
            'vehicle' => 'Vehicle',
            'plate_number' => 'Plate Number',
            'add_more' => 'Add More',
            'new_plate' => 'New Plate',
            'save' => 'Save',
            'cancel' => 'Cancel',
            //Messages
            'customer_notfound' => 'Customer Not Found',
            'customer_delete' => 'Customer has been deleted',
            'confirmation' => 'Confirmation',
            'user_arrival_notification' => 'Recieve e-mail notification when user has driven in?',
            'notify_email' => 'Emailadress for recieve notifications',
            'notify_email_note' => 'Enter more than 1 emails with comma(,) separated.',
];

