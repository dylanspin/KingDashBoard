<?php

return [
    'character_unwanted' => 'Unwanted Character',
    'valid_character' => 'Valid Character',
    'add_character' => 'Add Character',
    'edit_character' => 'Edit Character',
    'manage_character' => 'Manage Character',
    'view_character' => 'View Characters',
    'update_character'=> 'Update Character',
    'add_message' => 'Character Added Successfully',
    'update_message' => 'Character Updated Successfully'
];
