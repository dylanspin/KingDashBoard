<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'payments' => 'Payments',
    't_amount' => 'Total Amount :',
    't_bookings' => 'Total Bookings :',
    'today_amount' => 'Today Amount :',
    'today_bookings' => 'Today Bookings :',
    'name' => 'Name',
    'email' => 'Email',
    'type' => 'Type',
    'no' => 'No',
    'dob' => 'DOB',
    'date' => 'Date',
    'vehicle' => 'Vehicle',
    'amount' => 'Amount',
    'arrival' => 'Arrival',
    'departure' => 'Departure',
    'person_payment_transactions' => 'Person Payment Transaction',
    'vehicle_payment_transactions' => 'Vehicle Payment Transaction',
    'all_transactions' => 'All Transactions',
    'device' => 'Device',
    'quantity' => 'Quantity',
    'transaction_details' => 'E-Journal',
    'customer' => 'Customer',
    'online_payment' => 'Online Payment',
    'status' => 'Status',
    'payment_terminal' => 'Payment Terminal',
    'booking_not_found' => 'Booking not found.',
    'location_not_found' => 'Location doesnot exist.',
    'ticket_sent' => 'Ticket Sent Successfully.',
    'ticket_delete' => 'Ticket Delete Successfully.',
    'purchase_time' => 'Purchase Time',
    'booking'=>'Add Booking',
    'existing_vehicle' => 'Vehicle (Existing Plate Number)',
    'block' => 'Block',
    'unblock' => 'UnBlock',
    'block_really_vehicle' => 'Are you sure you want to block this vehicle?',
    'unblock_really_vehicle' => 'Do you want to unblocked this vehicle?',
    'block_really_person' => 'Are you sure you want to block this Person?',
    'unblock_really_person' => 'Do you want to unblocked this person ?',
    'block_vehicle' => 'Vehicle has been blocked',
    'block_person' => 'Person has been blocked',
    'unblock_vehicle' => 'Vehicle has been unblock',
    'unblock_person' => 'Person has been unblock',
    'not_found' => 'Record Not Found',
    'block_seasonal_vehicle' => 'Do you want to block parking subscription',
    'unblock_seasonal_vehicle' => 'Do you want to Unblocked parking subscription',
    'block_seasonal_person' => 'Do you want to block person subscription',
    'unblock_seasonal_person' => 'Do you want to Unblocked person subscription',
    
    
];
