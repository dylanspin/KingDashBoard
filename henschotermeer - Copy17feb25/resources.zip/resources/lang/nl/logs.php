<?php

return [
    //Index
    'logs' => 'Fout logboeken',
    'message' => 'Foutbericht',
    'type' => 'Fouttype',
    'line' => 'Foutlijn #',
    'added_at' => 'Toegevoegd op',
    'actions' => 'acties',
    'resolved' => 'Opgelost',
    //Message
    'message_update' => 'Logboek is bijgewerkt.',
];
