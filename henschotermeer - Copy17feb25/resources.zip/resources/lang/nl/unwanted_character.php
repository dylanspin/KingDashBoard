<?php

return [
    'character_unwanted' => 'Ongewenst karakter',
    'valid_character' => 'Geldig karakter',
    'add_character' => 'Karakter toevoegen',
    'edit_character' => 'Karakter bewerken',
    'manage_character' => 'Beheer karakter',
    'view_character' => 'Karakters bekijken',
    'update_character' => 'Karakter bijwerken',
    'add_message' => 'Karakter succesvol toegevoegd',
    'update_message' => 'Karakter succesvol bijgewerkt'
];
