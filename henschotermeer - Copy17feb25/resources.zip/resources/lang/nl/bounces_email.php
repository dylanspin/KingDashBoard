<?php

return [
   'bounces_email' => 'Teruggestuurde e-mails',
    'no' => 'Nee',
    'email' => 'E-mail',
    'reason' => 'Reden',
	'name' => 'Naam',
	'booking_ref' => 'Booking Id',
    'bounce_date' => 'Terugstuur datum',
    'search'  => 'Zoeken',
    'search_in'  => 'Zoek in',
    'reset'  => 'Filter resetten',
    'export_to_excel'  => 'Exporteren naar Excel',
];
