<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'attendants' => 'Aankomstlijst',
    'no' => 'Nee',
    'users' => 'Gebruikers',
    'vehicle' => 'Voertuig',
    'phone' => 'Telefoon',
    'authorized_by' => 'Gemachtigd door',
    'type' => 'Type'
    
];
