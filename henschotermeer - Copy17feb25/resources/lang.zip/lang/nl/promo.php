<?php

return [
    //Manage Promo
    'promo' => 'promos',
    'add_promo' => 'Promo toevoegen',
    'promo_code' => 'Promotiecode',
    'type' => 'Type',
    'discount' => 'Korting',
    'validity' => 'deugdelijkheid',
    'status' => 'staat',
    'send' => 'Sturen',
    'edit' => 'Bewerk',
    'delete' => 'Verwijder',
    'actions' => 'acties',
    'no' => 'No',
    'email' => 'E-mail',
    //Create Promo
    'create_promo' => 'Maak een Promo',
    'view_promos' => 'Bekijk Promo\'s',
    'discount_type' => 'Kortingstype',
    'select' => 'kiezen',
    'price' => 'Prijs',
    'percentage' => 'Percentage',
    'valid_number_of_times' => 'Aantal keren',
    'valid_dates' => 'Kies bereik',
    'submit' => 'voorleggen',
    'total_bookings' => 'Totale boekingen',
    'total_arrivals' => 'Totaal aantal aankomsten',
    //Messages
    'promo_added' => 'Promo is gemaakt.',
    'promo_send' => 'Promo-uitnodiging is verzonden.',
    'promo_not_send' => 'Er is iets fout gegaan! E-mail niet verzonden.',
    'promo_delete' => 'Promo is verwijderd.',
    'promo_not_found' => 'Promo niet gevonden.'
];
