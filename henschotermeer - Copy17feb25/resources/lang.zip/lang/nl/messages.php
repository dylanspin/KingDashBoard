<?php

return [
    //Index
    'messages' => 'Berichten',
    'add_message' => 'Bericht toevoegen',
    'message_en_uk' => 'Bericht Engels (UK)',
    'message_dutch_nl' => 'Bericht Nederlands (NL)',
    'delete' => 'Verwijder',
    'key' => 'Sleutel',
    'actions' => 'Acties',
    'edit' => 'Bewerken',
    'view' => 'Bekijken',
    //Edit,Create
    'message' => 'Bericht',
    'details' => 'Details',
    'message_in' => 'Bericht in',
    'finish' => 'Wijzigen opslaan',
    //Message
    'message_key_required' => 'Berichtsleutel is vereist',
    'message_lang_en_required' => 'Bericht in het Engels is verplicht',
    'message_add' => 'Bericht is toegevoegd.',
    'message_update' => 'Bericht is bijgewerkt.',
    'message_delete' => 'Bericht is verwijderd',
    'message_not_found' => 'Bericht niet gevonden'
];
