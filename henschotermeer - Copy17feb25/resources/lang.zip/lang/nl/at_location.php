<?php

return
[
    'curr_location' => 'Momenteel op Locatie',
    'name' => 'Naam',
    'email' => 'E-mail',
    'phone' => 'Telefoon',
    'vehicle' => 'Voertuig',
    'amount' => 'Bedrag',
    'checkin' => 'Check in',
    'checkout' => 'Check out',
    'transactions' => 'Transacties',
    'img' => 'Afbeelding',
    'check_in' => 'Check in',
    'check_out' => 'Check out',
    'contact_details' => 'Contact details',
    'type' => 'Type',
    'entry' => 'binnenkomst',
    'exit' => 'Uitgang',
    'device' => 'Apparaat',
    'status' => 'staat'
];

