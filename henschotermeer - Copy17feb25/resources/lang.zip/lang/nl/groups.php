<?php

return [
    'groups' => 'groepen',
    'add_group' => 'Groep toevoegen',
    'no' => 'Nee',
    'group_name' => 'Groepsnaam',
    'no_of_devices' => 'Apparaten',
    'actions' => 'Acties',
    'edit' => 'Bewerken',
    'delete' => 'Verwijder',
    'edit_group' => 'Groep bewerken',
    'view_groups' => 'Bekijk Groepen',
    'name' => 'Naam',
    'devices' => 'Apparaten',
    'submit' => 'Versturen',
    'device_title' => 'Selecteer apparaten ...',
    'create_group' => 'Maak een groep',
    'has_anti_pass_back' => 'Has Anti Pass Back?',
    //Messages
    'group_name_required' => 'De naam is verplicht',
    'group_device_required' => 'Selecteer een apparaat',
    'group_added' => 'Groep is toegevoegd.',
    'group_already_added' => 'Groep is al toegevoegd.',
    'group_updated' => 'Groep is bijgewerkt.',
    'group_not_found' => 'Groep niet gevonden.',
    'group_deleted' => 'Groep is verwijderd.',
];

