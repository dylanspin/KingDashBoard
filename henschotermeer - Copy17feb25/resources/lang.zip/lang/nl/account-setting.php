<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return [
    'account_settings' => 'Account instellingen',
    'user_profile' => 'Gebruikersprofiel',
    'bio' => 'Bio',
    'address' => 'Adres',
    'name' => 'Naam',
    'email' => 'E-mail',
    'password_msg' => 'Als u geen wachtwoord wilt wijzigen ... laat het dan leeg',
    'pass' => 'Wachtwoord',
    'confirm_pass' => 'bevestig wachtwoord',
    'dob' => 'Geboortedatum',
    'profile_pic' => 'Profielfoto',
    'select_img' => 'Selecteer foto',
    'change' => 'Veranderen',
    'remove' => 'Verwijderen',
    'brief_intro' => 'kort Intro',
    'gender' => 'Geslacht',
    'select' => 'kiezen',
    'select_gender' => 'Selecteer geslacht...',
    'male' => 'Man',
    'female' => 'Vrouw',
    'other' => 'anders',
    'country' => 'Land',
    'state' => 'Staat',
    'city' => 'Stad',
    'postal' => 'Postcode',
    'prev' => 'vorige',
    'nxt' => 'volgende',
    'finish' => 'Wijzigen opslaan',
    'error_msg' => 'Fouten! Vul het formulier in met de juiste gegevens'
];
