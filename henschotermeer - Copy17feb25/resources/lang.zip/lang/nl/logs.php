<?php

return [
    //Index
    'logs' => 'Foutlogboeken',
    'message' => 'Foutbericht',
    'type' => 'Fouttype',
    'line' => 'Foutlijn #',
    'added_at' => 'At toegevoegd',
    'actions' => 'acties',
    'resolved' => 'Vastbesloten',
    //Message
    'message_update' => 'Logboek is bijgewerkt.',
];
