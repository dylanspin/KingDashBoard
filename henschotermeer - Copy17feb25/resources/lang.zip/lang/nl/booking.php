<?php

return
[
    't_bookings' => 'Totaal reserveringen',
    't_payments' => 'Totaal betalingen',
    'booking_details' => 'Reserveringsdetails',
    'booking_transactions' => 'Reservering',
    'check_in' => 'Check In',
    'check_out' => 'Check Out',
    'vehicle_no' => 'Kenteken',
    'attendant_name' => 'Naam bezoeker',
    'trans_img' => 'Transactie afbeelding',
    'user_name' => 'Gebruikersnaam',
    'email' => 'E-mail',
    'booking_payment' => 'Reserveringsbetaling',
    'group_bookings' => 'Groepsboekingen',
    'expected_bookings' => 'Verwachte boekingen',
    'unexpected_bookings' => 'Onverwachte boekingen',
    'on_location' => 'Op locatie',
    'left' => 'Links',
    'alert_details' => 'Waarschuwingsdetails',
    'no' => 'Nee.',
    'device' => 'Apparaat',
    'status' => 'staat',
    'message' => 'Bericht'
];