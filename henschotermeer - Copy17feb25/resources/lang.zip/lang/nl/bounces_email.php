<?php

return [
    'bounces_email' => 'Niet aangekomen e-mails',
    'no' => 'Nee',
    'email' => 'E-mail',
    'reason' => 'Reden',
    'bounce_date' => 'Bounce datum'
];
