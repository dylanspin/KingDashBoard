﻿<?php

return [
    'person_ticket_added' => 'Persoon ticket is succesvol toegevoegd',
    'person_ticket_updated' => 'Persoon ticket succesvol geüpdatet',
    'day_ticket_added' => 'Dagkaart parkeren is succesvol toegevoegd',
    'day_ticket_updated' => 'Dagkaart parkeren succesvol bijgewerkt',
    'day_ticket' => 'Dagkaart parkeren',
    'person_ticket' => 'Persoon ticket',
    'title' => 'Titel',
    'title_nl' => 'Titel NL',
    'price' => 'Prijs',
    'submit' => 'Versturen'
];
