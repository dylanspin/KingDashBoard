<?php

return
[
    'account_settings' => 'Account instellingen',
    'logout' => 'Uitloggen',
    'login' => 'Login',
    'register' => 'Registreren',
    'actions' => 'acties',
    'checkout_person' => 'Check-out persoon',
    'checkout_vehicle' => 'Check-out voertuig'
];
