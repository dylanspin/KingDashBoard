<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'title' => 'Reservations import',
    'import_data' => 'Import Data',
    'no' => 'No',
    'email' => 'Email',
    't_members' => 'Members',
    'arrival_date' => 'Arrival Date',
    'departure_date' => 'Departure Date',
    'license_plate' => 'License Plate',
    'actions' => 'Actions',
    'send_ticket' => 'Send Ticket',
    'delete' => 'Delete',
    'name' => 'Name',
    'family_status' => 'Family Status',
    'dob' => 'Date Of Birth',
    'mem_of' => 'Guest & companion',

    //Import
    'import_reservation' => 'Import Reservation',
    'view_reservations' => 'View Reservations',
    'file_chooser' => 'Choose your xls/csv File:',
    'import' => 'Import',
    'print' => 'Print Ticket',
    'family_name' => 'Family Name'
];
