<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
[
    'payments' => 'Payments',
    't_amount' => 'Total Amount :',
    't_bookings' => 'Total Bookings :',
    'today_amount' => 'Today Amount :',
    'today_bookings' => 'Today Bookings :',
    'name' => 'Name',
    'email' => 'Email',
    'type' => 'Type',
    'no' => 'No',
    'dob' => 'DOB',
    'date' => 'Date',
    'vehicle' => 'Vehicle',
    'amount' => 'Amount',
    'arrival' => 'Arrival',
    'departure' => 'Departure',
    'person_payment_transactions' => 'Person Payment Transaction',
    'vehicle_payment_transactions' => 'Vehicle Payment Transaction',
    'all_transactions' => 'All Transactions',
    'device' => 'Device',
    'quantity' => 'Quantity',
    'transaction_details' => 'E-Journal',
    'customer' => 'Customer',
    'online_payment' => 'Online Payment',
    'status' => 'Status',
    'payment_terminal' => 'Payment Terminal',
    'booking_not_found' => 'Booking not found.',
    'location_not_found' => 'Location doesnot exist.',
    'ticket_sent' => 'Ticket Sent Successfully.',
];
