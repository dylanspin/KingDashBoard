<?php

return [
    //Index
    'messages' => 'Messages',
    'add_message' => 'Add Message',
    'message_en_uk' => 'Message English (UK)',
    'message_dutch_nl' => 'Message Dutch (NL)',
    'delete' => 'Delete',
    'key' => 'Key',
    'actions' => 'Actions',
    'edit' => 'Edit',
    'view' => 'View',
    //Edit,Create
    'message' => 'Message',
    'details' => 'Details',
    'message_in' => 'Message in',
    'finish' => 'Finish',
    //Message
    'message_key_required' => 'Message key is required',
    'message_lang_en_required' => 'Message in english is required',
    'message_add' => 'Message has been added.',
    'message_update' => 'Message has been updated.',
    'message_delete' => 'Message has been deleted.',
    'message_not_found' => 'Message not found'
];
