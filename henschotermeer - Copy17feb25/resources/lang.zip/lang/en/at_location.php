<?php

return
[
    'curr_location' => 'Currently at Location',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'vehicle' => 'Vehicle',
    'amount' => 'Amount',
    'checkin' => 'Check_in',
    'checkout' => 'Check_out',
    'transactions' => 'Transactions',
    'img' => 'Image',
    'check_in' => 'Check-in',
    'check_out' => 'Check-out',
    'contact_details' => 'Contact Details',
    'type' => 'Type',
    'entry' => 'Entry',
    'exit' => 'Exit',
    'device' => 'Device',
    'status' => 'Status'
];

