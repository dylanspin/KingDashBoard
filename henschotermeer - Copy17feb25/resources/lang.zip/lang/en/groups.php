<?php

return [
    'groups' => 'Groups',
    'add_group' => 'Add Group',
    'no' => 'No',
    'group_name' => 'Group Name',
    'no_of_devices' => 'Devices',
    'actions' => 'Actions',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'edit_group' => 'Edit Group',
    'view_groups' => 'View Groups',
    'name' => 'Name',
    'devices' => 'Devices',
    'submit' => 'Submit',
    'device_title' => 'Select Devices...',
    'create_group' => 'Create Group',
    'has_anti_pass_back' => 'Has Anti Pass Back?',
    //Messages
    'group_name_required' => 'The name is required',
    'group_device_required' => 'Please select a device',
    'group_added' => 'Group has been added.',
    'group_already_added' => 'Group already added.',
    'group_updated' => 'Group has been updated.',
    'group_not_found' => 'Group not found.',
    'group_deleted' => 'Group has been deleted.',
];

