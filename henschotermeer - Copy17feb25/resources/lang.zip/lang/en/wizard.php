<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return
        [
//Step-0
            'conn_details' => 'Enter Database Connection Details',
            'user' => 'User',
            'port' => 'Port',
            'pass' => 'Password',
            'db_name' => 'Db Name',
            'nxt' => 'Next',
            //step-1
            'activation_key' => 'Enter activation key provided by Parkingshop',
            'active_key' => 'Activation Key',
            //step-2
            'add_device_info' => 'Do you want to enter Devices Information, You can add this later.',
            'yes' => 'Yes',
            'no' => 'No',
            //Step-3
            'ticket_reader_no' => 'How many ticket reader you want to configure at this location?',
            'ticket_readers' => 'Ticket Readers',
            'person_ticket_readers' => 'Person Ticket Readers',
            'plate_readers' => 'Plate Readers',
            'outdoor_display' => 'Outdoor Display',
            //Step4
            'conf_ticket_reader' => 'Configuration of Ticket Readers',
            'name_ticket_reader' => 'Name for Ticket Reader',
            'device_direction' => 'Device Direction',
            'bi_directional' => 'Bi-Directional',
            'in' => 'In',
            'out' => 'Out',
            'port_treader' => 'Port for Ticket Reader',
            'ip_treader' => 'Ip for Ticket Reader',
            'skip' => 'Skip',
            'import' => 'Import Settings to Device?',
            //Step-5
            'config_person_TReader' => 'Configuration of Person Ticket Readers',
            'name_person_TReader' => 'Name for Person Ticket Reader',
            'ip_preader' => 'Ip for Person Ticket Reader',
            'port_preader' => 'Port for Person Ticket Reader',
            //Step-6
            'config_plate_reader' => 'Configuration of Plate Readers',
            'name_plate_reader' => 'Name for Plate Reader',
            'port_plate_reader' => 'Port for Plate Reader',
            'ip_plate_reader' => 'Ip for Plate Reader',
            //Step7
            'config_outdoor_display' => 'Configuration of Outdoor Display',
            'name_outdoor_display' => 'Name for Outdoor Display',
            'port_outdoor_display' => 'Port for Outdoor Display',
            'ip_outdoor_display' => 'IP for Outdoor Display',
            //Step-8
            'thanks' => 'Thanks For Completing Wizard.',
            'finish' => 'Finish'

];
