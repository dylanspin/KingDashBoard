<?php

return [
    //Manage Promo
    'promo' => 'Promos',
    'add_promo' => 'Add Promo',
    'promo_code' => 'Promo Code',
    'type' => 'Type',
    'discount' => 'Discount',
    'validity' => 'Validity',
    'status' => 'Status',
    'send' => 'Send',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'actions' => 'Actions',
    'no' => 'No',
    'email' => 'Email',
    //Create Promo
    'create_promo' => 'Create Promo',
    'view_promos' => 'View Promos',
    'discount_type' => 'Discount Type',
    'select' => 'Select',
    'price' => 'Price',
    'percentage' => 'Percentage',
    'valid_number_of_times' => 'Number of Times',
    'valid_dates' => 'Choose Range',
    'submit' => 'Submit',
    'total_bookings' => 'Total Bookings',
    'total_arrivals' => 'Total Arrivals',
    //Messages
    'promo_added' => 'Promo has been created.',
    'promo_send' => 'Promo Invitation has been send.',
    'promo_not_send' => 'Some thing went wrong! Email not send.',
    'promo_delete' => 'Promo has been deleted.',
    'promo_not_found' => 'Promo not Found.'
];
