<?php

return
[
    'v_bookings' => 'Vehicle Bookings',
    'p_bookings' => 'Person Bookings',
    't_bookings' => 'Life Time Booking',
    'user_name' => 'User Name',
    'user_email' => 'User Email',
    'check_in' => 'Check In',
    'check_out' => 'Check Out',
    'transaction_imgs' => 'Transaction Images',
    'transactions' => 'Transactions',
    'vehicle_transactions' => 'Vehicle Transactions',
    'table_text' => 'Create responsive tables by wrapping any',
    'attendant_name' => 'Attendant Name',
    'v_number' => 'License Plate',
    'contact_details' => 'Contact Details'
];

