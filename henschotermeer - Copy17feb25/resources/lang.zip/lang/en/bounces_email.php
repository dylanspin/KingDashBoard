<?php

return [
    'bounces_email' => 'Bounced Emails',
    'no' => 'No',
    'email' => 'Email',
    'reason' => 'Reason',
    'bounce_date' => 'Bounce Date'
];
